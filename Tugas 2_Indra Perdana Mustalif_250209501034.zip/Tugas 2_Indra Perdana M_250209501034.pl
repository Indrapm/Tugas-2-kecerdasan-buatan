%fact jenis kelamin
laki(hamid).
laki(rustam).
laki(rahim).
laki(mustamin).
laki(indra).
laki(sakti).

perempuan(allae).
perempuan(dewi).
perempuan(nurkafila).
perempuan(defika).
perempuan(adeeva).

%fact hubungan(orangtua,anak)
orangtua(hamid,rustam).
orangtua(allae, rustam).
orangtua(hamid, dewi).
orangtua(allae, dewi).
orangtua(hamid, rahim).
orangtua(allae, rahim).
orangtua(hamid, nurkafila).
orangtua(allae, nurkafila).
orangtua(hamid, defika).
orangtua(allae, defika).

orangtua(nurkafila, indra).
orangtua(mustamin, indra).
orangtua(nurkafila, sakti).
orangtua(mustamin, sakti).
orangtua(nurkafila, adeeva).
orangtua(mustamin, adeeva).

%query mencari hubungan antara anggota keluarga
ibu(X,Y):-orangtua(X,Y),perempuan(X).
ayah(X,Y):-orangtua(X,Y),laki(X).

anak(X,Y):-orangtua(Y,X).
anaklaki(Y,X):-orangtua(Y,X),laki(X).
anakperempuan(X,Y):-orangtua(Y,X),perempuan(X).

menikah(X,Y):-anak(P,X),anak(P,Y),laki(Y).
istri(Y,X):-anak(P,X),anak(P,Y),perempuan(Y).
suami(Y,X):-anak(P,X),anak(P,Y),laki(Y).

kakek(X,Z):-orangtua(X,Y),orangtua(Y,Z),laki(x).
nenek(X,Z):-ibu(X,Y),ibu(Y,Z).

saudara(Y,Z):-anak(Y,X),anak(Z,X),Y\==Z.
saudaralaki(Y,Z):-anak(Y,X),anak(Z,X),laki(Y),Y\==Z.
saudaraperempuan(Y,Z):-anak(Y,X),anak(Z,X),perempuan(Y),Y\==Z.

bibi(X,Y):-saudara(X,Z),orangtua(Z,Y),perempuan(X),not(ibu(X,Y)).
paman(X,Y):-saudara(X,Z),orangtua(Z,Y),laki(X),not(ayah(X,Y)).

cuculaki(X,Z):-anak(X,Y),orangtua(Z,Y),laki(X).
cucuperempuan(X,Z):-anak(X,Y),orangtua(Z,Y),perempuan(X).
